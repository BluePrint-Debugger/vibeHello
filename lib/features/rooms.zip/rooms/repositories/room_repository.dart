import 'package:cloud_firestore/cloud_firestore.dart';

class RoomRepository {
  RoomRepository._();

  static final RoomRepository instance = RoomRepository._();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference<Map<String, dynamic>> get rooms =>
      _firestore.collection('rooms');

  DocumentReference<Map<String, dynamic>> room(String roomId) =>
      rooms.doc(roomId);

  CollectionReference<Map<String, dynamic>> seats(String roomId) =>
      room(roomId).collection('seats');

  CollectionReference<Map<String, dynamic>> members(String roomId) =>
      room(roomId).collection('members');

  CollectionReference<Map<String, dynamic>> lobby(String roomId) =>
      room(roomId).collection('lobby');

  CollectionReference<Map<String, dynamic>> admins(String roomId) =>
      room(roomId).collection('admins');

  CollectionReference<Map<String, dynamic>> messages(String roomId) =>
      room(roomId).collection('messages');

  CollectionReference<Map<String, dynamic>> events(String roomId) =>
      room(roomId).collection('room_events');

  // -------------------------
  // ROOM
  // -------------------------

  Future<DocumentSnapshot<Map<String, dynamic>>> getRoom(String roomId) {
    return room(roomId).get();
  }

  Stream<DocumentSnapshot<Map<String, dynamic>>> roomStream(String roomId) {
    return room(roomId).snapshots();
  }

  Future<void> updateRoom(String roomId, Map<String, dynamic> data) {
    return room(roomId).update(data);
  }

  // -------------------------
  // SEATS
  // -------------------------

  Stream<QuerySnapshot<Map<String, dynamic>>> seatsStream(String roomId) {
    return seats(roomId).orderBy("seatNumber").snapshots();
  }

  Future<DocumentSnapshot<Map<String, dynamic>>> getSeat(
    String roomId,
    int seatNumber,
  ) {
    return seats(roomId).doc("seat_$seatNumber").get();
  }

  Future<void> updateSeat(
    String roomId,
    int seatNumber,
    Map<String, dynamic> data,
  ) {
    return seats(roomId).doc("seat_$seatNumber").update(data);
  }

  Future<void> setSeat(
    String roomId,
    int seatNumber,
    Map<String, dynamic> data,
  ) {
    return seats(
      roomId,
    ).doc("seat_$seatNumber").set(data, SetOptions(merge: true));
  }

  // -------------------------
  // MEMBERS
  // -------------------------

  Stream<QuerySnapshot<Map<String, dynamic>>> membersStream(String roomId) {
    return members(roomId).snapshots();
  }

  Future<void> updateMember(
    String roomId,
    String uid,
    Map<String, dynamic> data,
  ) {
    return members(roomId).doc(uid).update(data);
  }

  Future<void> setMember(String roomId, String uid, Map<String, dynamic> data) {
    return members(roomId).doc(uid).set(data, SetOptions(merge: true));
  }

  Future<void> deleteMember(String roomId, String uid) {
    return members(roomId).doc(uid).delete();
  }

  // -------------------------
  // EVENTS
  // -------------------------

  Future<void> addEvent(String roomId, Map<String, dynamic> data) {
    return events(roomId).add(data);
  }

  // -------------------------
  // FIRESTORE HELPERS
  // -------------------------

  Future<T> transaction<T>(TransactionHandler<T> handler) {
    return _firestore.runTransaction(handler);
  }

  WriteBatch batch() => _firestore.batch();
}
