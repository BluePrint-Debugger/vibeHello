enum RoomRole { listener, speaker, moderator, admin, host }

extension RoomRoleX on RoomRole {
  String get value => name;

  static RoomRole fromString(String? value) {
    switch (value) {
      case 'host':
        return RoomRole.host;

      case 'admin':
        return RoomRole.admin;

      case 'moderator':
        return RoomRole.moderator;

      case 'speaker':
        return RoomRole.speaker;

      default:
        return RoomRole.listener;
    }
  }
}
