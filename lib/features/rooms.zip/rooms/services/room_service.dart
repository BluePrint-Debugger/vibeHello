import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/room_role.dart';
import '../repositories/room_repository.dart';

class RoomService {
  RoomService._();

  static final RoomService instance = RoomService._();

  final RoomRepository _repository = RoomRepository.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  //==========================================================
  // JOIN SEAT
  //==========================================================

  Future<void> joinSeat({
    required String roomId,
    required int seatNumber,
    required String uid,
    required String name,
    required String photo,
    required RoomRole role,
  }) async {
    await _firestore.runTransaction((transaction) async {
      final seatRef = _repository.seats(roomId).doc("seat_$seatNumber");

      final memberRef = _repository.members(roomId).doc(uid);

      final roomRef = _repository.room(roomId);

      final seatSnapshot = await transaction.get(seatRef);

      if (!seatSnapshot.exists) {
        throw Exception("Seat does not exist.");
      }

      final seat = seatSnapshot.data()!;

      if (seat["state"] == "locked") {
        throw Exception("Seat is locked.");
      }

      if (seat["state"] == "occupied") {
        throw Exception("Seat already occupied.");
      }

      transaction.update(seatRef, {
        "state": "occupied",
        "userId": uid,
        "userName": name,
        "photo": photo,
        "role": role.value,
        "micOn": true,
        "isSpeaking": false,
        "mutedByAdmin": false,
        "joinedAt": FieldValue.serverTimestamp(),
      });

      transaction.set(memberRef, {
        "uid": uid,
        "name": name,
        "photo": photo,
        "role": role.value,
        "seatNumber": seatNumber,
        "micOn": true,
        "isSpeaking": false,
        "mutedByAdmin": false,
        "chatBlocked": false,
        "joinedAt": FieldValue.serverTimestamp(),
      });

      transaction.update(roomRef, {"usersCount": FieldValue.increment(1)});

      transaction.set(_repository.events(roomId).doc(), {
        "type": "joined",
        "uid": uid,
        "name": name,
        "seatNumber": seatNumber,
        "createdAt": FieldValue.serverTimestamp(),
      });
    });
  }

  //==========================================================
  // LEAVE SEAT
  //==========================================================

  Future<void> leaveSeat({
    required String roomId,
    required int seatNumber,
    required String uid,
  }) async {
    await _firestore.runTransaction((transaction) async {
      final seatRef = _repository.seats(roomId).doc("seat_$seatNumber");

      final memberRef = _repository.members(roomId).doc(uid);

      final roomRef = _repository.room(roomId);

      transaction.update(seatRef, {
        "state": "open",
        "userId": null,
        "userName": null,
        "photo": null,
        "role": RoomRole.listener.value,
        "micOn": false,
        "isSpeaking": false,
        "mutedByAdmin": false,
        "joinedAt": null,
      });

      transaction.delete(memberRef);

      transaction.update(roomRef, {"usersCount": FieldValue.increment(-1)});

      transaction.set(_repository.events(roomId).doc(), {
        "type": "left",
        "uid": uid,
        "seatNumber": seatNumber,
        "createdAt": FieldValue.serverTimestamp(),
      });
    });
  }

  //==========================================================
  // SWITCH SEAT
  //==========================================================

  Future<void> switchSeat({
    required String roomId,
    required int fromSeat,
    required int toSeat,
    required String uid,
  }) async {
    await _firestore.runTransaction((transaction) async {
      final fromRef = _repository.seats(roomId).doc("seat_$fromSeat");

      final toRef = _repository.seats(roomId).doc("seat_$toSeat");

      final memberRef = _repository.members(roomId).doc(uid);

      final from = await transaction.get(fromRef);

      final to = await transaction.get(toRef);

      if (!to.exists) {
        throw Exception("Target seat not found.");
      }

      if (to["state"] == "occupied") {
        throw Exception("Target seat occupied.");
      }

      if (to["state"] == "locked") {
        throw Exception("Target seat locked.");
      }

      final fromData = from.data()!;

      transaction.update(toRef, {...fromData, "seatNumber": toSeat});

      transaction.update(fromRef, {
        "state": "open",
        "userId": null,
        "userName": null,
        "photo": null,
        "role": RoomRole.listener.value,
        "micOn": false,
        "isSpeaking": false,
      });

      transaction.update(memberRef, {"seatNumber": toSeat});

      transaction.set(_repository.events(roomId).doc(), {
        "type": "switch",
        "uid": uid,
        "fromSeat": fromSeat,
        "toSeat": toSeat,
        "createdAt": FieldValue.serverTimestamp(),
      });
    });
  }
}
